from pymavlink import mavutil

def get_current_location():
    # Connect to the vehicle
    mav = mavutil.mavlink_connection('tcp:23.105.171.72:14550')
    
    # Wait for the heartbeat message to find the system ID
    mav.wait_heartbeat()
    
    # Request the GPS coordinates
    mav.mav.command_long_send(
        mav.target_system, # target_system
        mav.target_component, # target_component
        mavutil.mavlink.MAV_CMD_REQUEST_POSITION, # command
        0, # confirmation
        1, # param1
        0, # param2
        0, # param3
        0, # param4
        0, # param5
        0, # param6
        0  # param7
    )
    
    # Wait for the GPS message
    msg = None
    while msg is None or msg.get_type() != 'GLOBAL_POSITION_INT':
        msg = mav.recv_match(type='GLOBAL_POSITION_INT')
    
    # Parse the message for the latitude, longitude, and altitude
    lat = msg.lat / 1.0e7
    lon = msg.lon / 1.0e7
    alt = msg.alt / 1000.0
    
    return (lat, lon, alt)
